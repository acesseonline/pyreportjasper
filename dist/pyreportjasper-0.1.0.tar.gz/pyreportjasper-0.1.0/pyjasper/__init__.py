# -*- coding: utf-8 -*-
__version__ = '0.1'

from pyjasper.jasperpy import JasperPy
